package com.crazyaim.bot

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val captureRequest = 4101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 48, 28, 28)
            setBackgroundColor(0xFF101318.toInt())
        }
        fun label(value: String, size: Float = 18f) = TextView(this).apply {
            text = value; textSize = size; setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER; setPadding(8, 16, 8, 16)
        }
        fun addButton(value: String, action: () -> Unit) {
            layout.addView(Button(this).apply { text = value; setOnClickListener { action() } },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 10 })
        }
        layout.addView(label("CRAZY AIM BOT", 26f))
        layout.addView(label("Android prototype • v0.1.0"))
        status = label("Status: idle"); layout.addView(status)
        addButton("Grant screen capture") {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
        }
        addButton("Open Accessibility settings") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        addButton("START (prototype)") { status.text = "Status: prototype ready; gameplay automation not implemented yet" }
        addButton("STOP") { status.text = "Status: stopped" }
        layout.addView(label("This starter does not yet detect targets, calculate shots, or play levels automatically.", 14f))
        setContentView(layout)
    }

    @Deprecated("Deprecated Android callback retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest) status.text =
            if (resultCode == RESULT_OK && data != null) "Status: screen-capture consent granted" else "Status: screen capture not granted"
    }
}
