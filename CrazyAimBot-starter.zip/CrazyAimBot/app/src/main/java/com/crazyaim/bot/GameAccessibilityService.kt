package com.crazyaim.bot
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/** Permission-gated service foundation; no gestures are dispatched in this starter. */
class GameAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit
}
