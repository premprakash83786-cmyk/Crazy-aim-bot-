# Crazy Aim Bot — Android starter

A buildable native Android starter for a user-authorized game-assistance prototype.

## Implemented
- Native launcher screen
- Screen-capture consent request
- Accessibility-service declaration and stub
- GitHub Actions workflow to build a debug APK

## Not implemented yet
- Frame capture and image processing
- Enemy/obstacle detection
- Trajectory solver
- Automated aiming/firing
- Automatic stage progression

This is not yet a completed game-playing bot. These features require implementation and testing against actual gameplay.

## Build
Push the project to the `main` branch. GitHub Actions builds `app-debug.apk`; alternatively run the workflow manually from the Actions tab.
